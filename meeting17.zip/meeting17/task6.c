// 3адача 6. Напишете програма, която да изчислява средния успех на всеки 
// студент и целия курс, използвайки структури. Входните данни за студентите 
// трябва да бъдат въведени от потребителя. Принтирайте резултатите за 
// всеки студент поотделно, както и за целия курс.

#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    float averageGrade;
    float gradeBulgarian;
    float gradeEnglish;
} Student;

void printStudent(Student *ptr) {
    printf("Student Grade Bulgarian: %lf", ptr->gradeBulgarian);
    printf("Student Grade English: %lf", ptr->gradeEnglish);
}

int main() {
    int countStudent = 0;
    double averageTotal = 0.0;
    printf("Enter number of students: ");
    scanf("%d", &countStudent);
    Student *classStudent = (Student*) malloc(countStudent * sizeof(Student));
    for (int i = 0; i < countStudent; i++)
    {
        printf("\n\n\n\n\n\n\n");
        printf("Grade Bulgarian: ");
        scanf("%f", &classStudent[i].gradeBulgarian);
        printf("Grade English: ");
        scanf("%f", &classStudent[i].gradeEnglish);
        classStudent[i].averageGrade = (classStudent[i].gradeBulgarian + classStudent[i].gradeEnglish) / 2;
        averageTotal += classStudent[i].averageGrade;
    }
    averageTotal /= (double)countStudent;

    printf("Average total: %.3lf", averageTotal);

    return 0;
}