// Задача 1. Напишете програма, в която информацията да бъде съхранявана 
// в структура, описваща автомобил. Входната информация трябва бъде 
// въведена от потребителя, като напишете меню с въпроси към него. 
// Принтирайте въведената информация за описание на автомобила

#include <stdio.h>

#define MODEL_STR_LEN 50

struct autoCar
{
    char *autoModel[50];
    char *autoType[50];
    int autoYearOfCreation;
    float autoEngine;
};

void printCar(struct autoCar *carDetails) {
    printf("Your car model is %s.\n", carDetails->autoModel);
    printf("It's a %s.\n", carDetails->autoType);
    printf("It's was created back in %d.\n", carDetails->autoYearOfCreation);
    printf("The car's engine is %.1f.", carDetails->autoEngine);    
}


int main() {
    struct autoCar myCar;
    printf("Enter your car's model:\n");
    scanf("%[^\n]s", myCar.autoModel);
    printf("Enter your car's type:\n");
    scanf("%s", myCar.autoType);
    printf("Enter your car's year of creator:\n");
    scanf("%d", &myCar.autoYearOfCreation);
    printf("Enter your car's engine size:\n");
    scanf("%f", &myCar.autoEngine);
    
    printCar(&myCar);

    return 0;
}