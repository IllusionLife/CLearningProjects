// Задача 3. Напишете програма, която калкулира разликата на два времеви 
// периода, изразени във векове, години, месеци, дни, (((часове))), минути, секудни. 
// Принтирайте изходните периоди и резултата.

#include <stdio.h>

typedef struct
{
    int centuries;
    int years;
    int months;
    int days;
    int hours;
    int minutes;
    int seconds;
} timestampRecord;

void timestampResultCorrection(timestampRecord *t1) {
    while (t1->seconds < 0)
    {
        (t1->minutes)--;
        t1->seconds += 60;
    }
    while (t1->minutes < 0)
    {
        (t1->hours)--;
        t1->minutes += 60;
    }
    while (t1->hours < 0)
    {
        (t1->days)--;
        t1->hours += 24;
    }
    while (t1->days < 0)
    {
        (t1->months)--;
        t1->days += 30;
    }
    while (t1->months < 0)
    {
        (t1->years)--;
        t1->months += 12;
    }
    while (t1->years < 0)
    {
        (t1->centuries)--;
        t1->years += 100;
    }
}

void timestampCorrection(timestampRecord *t1) {
    if (t1->seconds > 59)
    {
        t1->minutes += (t1->seconds / 60);
        t1->seconds %= 60; 
    }
    if (t1->minutes > 59)
    {
        t1->hours += (t1->minutes / 60);
        t1->minutes %= 60; 
    }
    if (t1->hours > 23) {
        t1->days += (t1->hours / 24);
        t1->hours %= 24; 
    }
    if (t1->days > 29)
    {
        t1->months += (t1->days / 30);
        t1->days %= 30; 
    }
    if (t1->months > 11)
    {
        t1->years += (t1->months / 12);
        t1->months %= 12; 
    }
    if (t1->years > 99)
    {
        t1->centuries += (t1->years / 100);
        t1->years %= 100; 
    }
}

int timestampBigger(timestampRecord *t1, timestampRecord *t2) {
    if (t1->centuries != t2->centuries)
    {
        if (t1->centuries > t2->centuries)
        {
            return 1;
        }
        else {
            return 2;
        }
    }
    else if (t1->years != t2->years)
    {
        if (t1->years > t2->years)
        {
            return 1;
        }
        else {
            return 2;
        }
    }
    else if (t1->months != t2->months)
    {
        if (t1->months > t2->months)
        {
            return 1;
        }
        else {
            return 2;
        }
    }
    else if (t1->days != t2->days)
    {
        if (t1->days > t2->days)
        {
            return 1;
        }
        else {
            return 2;
        }
    }
    else if (t1->hours != t2->hours)
    {
        if (t1->hours > t2->hours)
        {
            return 1;
        }
        else {
            return 2;
        }
    }
    else if (t1->minutes != t2->minutes)
    {
        if (t1->minutes > t2->minutes)
        {
            return 1;
        }
        else {
            return 2;
        }
    }
    else if (t1->seconds != t2->seconds)
    {
        if (t1->seconds > t2->seconds)
        {
            return 1;
        }
        else {
            return 2;
        }
    }
    return 0;    
}

void timestampCompare(timestampRecord *t1, timestampRecord *t2, timestampRecord *res) {
    timestampCorrection(t1);
    timestampCorrection(t2);
    switch (timestampBigger(t1, t2))
    {
        case 0:
            res->centuries = 0;
            res->years = 0;
            res->months = 0;
            res->days = 0;
            res->hours = 0;
            res->minutes = 0;
            res->seconds = 0;
            break;
        case 1:
            res->centuries = t1->centuries - t2->centuries;
            res->years = t1->years - t2->years;
            res->months = t1->months - t2->months;
            res->days = t1->days - t2->days;
            res->hours = t1->hours - t2->hours;
            res->minutes = t1->minutes - t2->minutes;
            res->seconds = t1->seconds - t2->seconds;
            timestampResultCorrection(res);
            break;
        case 2:
            res->centuries = t2->centuries - t1->centuries;
            res->years = t2->years - t1->years;
            res->months = t2->months - t1->months;
            res->days = t2->days - t1->days;
            res->hours = t2->hours - t1->hours;
            res->minutes = t2->minutes - t1->minutes;
            res->seconds = t2->seconds - t1->seconds;
            timestampResultCorrection(res);
            break;
        default:
            printf("An error occured!");
    }
}

void timestampPrint(timestampRecord *t1) {
    printf("Centuries: %d\n", t1->centuries);
    printf("Years: %d\n", t1->years);
    printf("Months: %d\n", t1->months);
    printf("Days: %d\n", t1->days);
    printf("Hours: %d\n", t1->hours);
    printf("Minutes: %d\n", t1->minutes);
    printf("Seconds: %d\n", t1->seconds);
}

void timestampFill(timestampRecord *t1) {
    printf("Enter centuries: ");
    scanf("%d", &t1->centuries);
    printf("Enter years: ");
    scanf("%d", &t1->years);
    printf("Enter months: ");
    scanf("%d", &t1->months);
    printf("Enter days: ");
    scanf("%d", &t1->days);
    printf("Enter hours: ");
    scanf("%d", &t1->hours);
    printf("Enter minutes: ");
    scanf("%d", &t1->minutes);
    printf("Enter seconds: ");
    scanf("%d", &t1->seconds);
}

int main() {
    timestampRecord timestamp1;
    timestampRecord timestamp2;
    timestampRecord timestampRes;

    printf("Timestamp 1\n");
    printf("-----------\n");
    timestampFill(&timestamp1);
    printf("Timestamp 2\n");
    printf("-----------\n");
    timestampFill(&timestamp2);
    printf("Timestamp 1 (before correction)\n");
    printf("-------------------------------\n");
    timestampPrint(&timestamp1);
    printf("Timestamp 2 (before correction)\n");
    printf("-------------------------------\n");
    timestampPrint(&timestamp2);

    timestampCompare(&timestamp1, &timestamp2, &timestampRes);

    printf("Timestamp 1 (after correction)\n");
    printf("-------------------------------\n");
    timestampPrint(&timestamp1);
    printf("Timestamp 2 (after correction)\n");
    printf("-------------------------------\n");
    timestampPrint(&timestamp2);
    printf("Timestamp difference\n");
    printf("--------------------\n");
    timestampPrint(&timestampRes);

    return 0;
}