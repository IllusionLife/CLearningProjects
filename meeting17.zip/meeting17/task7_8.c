// Задача 7. Направете функция struct point makepoint(int x, int y), която 
// създава две точки. Използвайте malloc().

// Задача 8. Направете структура struct rect, която съдържа в себе си две 
// точки. Създайте обект от тип тази структура наречен screen. Използвайте 
// функцията makepoint за да зададете начална точка на екрана (0, 0) и крайна 
// точка (15, 15). Запълнете пространството между тях с тирета.

#include <stdio.h>
#include <stdlib.h>

struct point
{
    int xCoord;
    int yCoord;
};

typedef struct
{
    struct point *startPoint;
    struct point *endPoint;
} rect;

struct point *makepoint(int x, int y) {
    struct point *newPoint = (struct point*) malloc(sizeof(struct point));
    newPoint->xCoord = x;
    newPoint->yCoord = y;
    return newPoint;
}

int main() {
    rect newRect;
    newRect.startPoint = makepoint(0, 0);
    newRect.endPoint = makepoint(15, 15);

    for (int i = 50; i > 0; i--)
    {
        for (int y = 0; y < 50; y++)
        {
            if (i <= newRect.endPoint->yCoord && i >= newRect.startPoint->yCoord)
            {
                if (y <= newRect.endPoint->xCoord && y >= newRect.startPoint->xCoord)
                {
                    putchar('-');
                    putchar(' ');
                }
                else {
                    putchar(' ');
                    putchar(' ');
                }
            }
            else {
                putchar(' ');
                putchar(' ');
            }
        }
        putchar('\n');
    }
    return 0;
}
