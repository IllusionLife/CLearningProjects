// Задача 2. Напишете програма, която събира две дистанции, които са 
// изразени в километри, метри, сантиметри. Дистанциите трябва да бъдат 
// въведени от потребителя. Принтирайте изходните и резултатната 
// дистанция.

#include <stdio.h>
#include <stdlib.h>

struct distCalc
{
    int dcKilometers;
    int dcMeters;
    int dcCentimeters;
};


void distanceCorrection(struct distCalc *d1) {
    if (d1->dcCentimeters > 99)
    {
        d1->dcMeters += (d1->dcCentimeters / 100);
        d1->dcCentimeters %= 100; 
    }
    if (d1->dcMeters > 999) {
        d1->dcKilometers += (d1->dcMeters / 1000);
        d1->dcMeters %= 1000; 
    }
}

void sumDistanceFunc(struct distCalc *d1, struct distCalc *d2, struct distCalc *sum) {
    int temp = 0;
    sum->dcCentimeters = d1->dcCentimeters + d2->dcCentimeters;
    sum->dcMeters = d1->dcMeters + d2->dcMeters;
    sum->dcKilometers = d1->dcKilometers + d2->dcKilometers;

    distanceCorrection(sum);
}

void printDist(struct distCalc *d1) {
    printf("\n-----------------------\n");
    printf("Kilometers %d\n", d1->dcKilometers);
    printf("Meters %d\n", d1->dcMeters);
    printf("Centimeters %d\n", d1->dcCentimeters);
    printf("\n-----------------------\n");
}

int main() {
    struct distCalc distance1;
    struct distCalc distance2;
    struct distCalc sumDistance;
    
    printf("Distance 1-\n");
    printf("Kilomerets:");
    scanf("%d", &distance1.dcKilometers);
    printf("Meters:");
    scanf("%d", &distance1.dcMeters);
    printf("Centimeters:");
    scanf("%d", &distance1.dcCentimeters);

    printf("\n\n\n");

    printf("Distance 2-\n");
    printf("Kilomerets:");
    scanf("%d", &distance2.dcKilometers);
    printf("Meters:");
    scanf("%d", &distance2.dcMeters);
    printf("Centimeters:");
    scanf("%d", &distance2.dcCentimeters);

    printf("Distance 1 (before correction)");
    printDist(&distance1);
    printf("Distance 2 (before correction)");
    printDist(&distance2);

    distanceCorrection(&distance1);
    distanceCorrection(&distance2);
    printf("Distance 1 (after correction)");
    printDist(&distance1);
    printf("Distance 2 (after correction)");
    printDist(&distance2);

    sumDistanceFunc(&distance1, &distance2, &sumDistance);

    printf("Distance sum");
    printDist(&sumDistance);

    return 0;
}