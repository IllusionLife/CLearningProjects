// Задача 9. Дефинирайте структура, в която има член указател към самата 
// структура. Използвайте тази структура, за да дефинирате две променливи, 
// които се указват една друга.

#include <stdio.h>
#include <string.h>
#include <Windows.h>

struct TicTac {
    char tick[5];
    struct TicTac *next;
};

typedef struct TicTac TicTac;

int main() {
    TicTac tic;
    TicTac tac;

    strcpy(tic.tick, "Tic\n");
    tic.next = &tac;
    strcpy(tac.tick, "Tac\n");
    tac.next = &tic;

    TicTac *ptr = &tic;
    while (1)
    {
        system("cls");
        printf("%s\n", ptr->tick);
        Sleep(1000);
        ptr = ptr->next;
        system("cls");       
        printf("%s\n", ptr->tick);
        Sleep(1000);
        ptr = ptr->next;
    }

    return 0;
}