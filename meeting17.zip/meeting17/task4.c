// Задача 4. Напишете произволна програма, която да демонстрира уменията 
// ви да боравите с nested structure.

#include <stdio.h>
#include <string.h>

typedef struct
{
    char model[32];
    char registration[9];
    char firstNameOwner[32];
    char lastNameOwner[32];
} Vehicle;

typedef struct {
    int beginDateDay;
    int beginDateMonth;
    int beginDateYear;
    int duration;
    Vehicle car;
} Vinetka;

typedef struct
{
    struct Fuel
    {
        int litersGas;
        int litersDiesel;
        int litersGasoline;
    } fuelQuantity;
    int sandwiches;
    int cigarettes;
} GasStation;

int main() {
    Vinetka newtype;
    newtype.beginDateDay = 8;
    newtype.beginDateMonth = 11;
    newtype.beginDateYear = 2021;
    newtype.duration = 365;
    strcpy(newtype.car.model, "Opel Astra");
    strcpy(newtype.car.registration, "EH3329KP");
    strcpy(newtype.car.firstNameOwner, "Marinos");
    strcpy(newtype.car.lastNameOwner, "Papadimitriu");

    printf("%s %s has purchased a vignette for %d days (starting %02d/%02d/%d).\n", newtype.car.firstNameOwner, newtype.car.lastNameOwner, newtype.duration, newtype.beginDateDay, newtype.beginDateMonth, newtype.beginDateYear);
    printf("The vignette is registered to the vehicle model \"%s\" with registration plates \"%s\"", newtype.car.model, newtype.car.registration);

    GasStation shell;
    shell.cigarettes = 108;
    shell.sandwiches = 45;
    shell.fuelQuantity.litersGasoline = 600;
    shell.fuelQuantity.litersDiesel = 450;
    shell.fuelQuantity.litersGas = 200;

    printf("\n\n\n\n");
    printf("The local Shell gas station has %d packs of cigarettes, %d sandwiches and %d liters of fuel.\n", shell.cigarettes, shell.sandwiches, (shell.fuelQuantity.litersDiesel + shell.fuelQuantity.litersGas + shell.fuelQuantity.litersGasoline));
    printf("The available fuel is in the following quantity:\n");
    printf("Gasolene: %d\n", shell.fuelQuantity.litersGasoline);
    printf("Gas: %d\n", shell.fuelQuantity.litersGas);
    printf("Diesel: %d\n", shell.fuelQuantity.litersDiesel);
    return 0;
}