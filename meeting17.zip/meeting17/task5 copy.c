// Задача 5. Напишете произволна програма, която демонстрира уменията ви 
// да боравите с указатели към структури. Нека декларираната от вас 
// структура(и) съдържа указател към собствения си тип.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct vehicle
{
    int status;
    int id;
    char model[32];
    char registration[9];
    char firstNameOwner[32];
    char lastNameOwner[32];
    long int number;
    struct vehicle *nextCar;
};

void registerParkingSpot (struct vehicle *parkplace) {
    parkplace->status = 1;
    printf("Enter car model: ");
    fflush(stdin);
    scanf("%[^\n]s", parkplace->model);
    printf("Enter car registration plate: ");
    scanf("%s", parkplace->registration);
    printf("Enter first name: ");
    scanf("%s", parkplace->firstNameOwner);
    printf("Enter last name: ");
    scanf("%s", parkplace->lastNameOwner);
    printf("Enter phone number: ");
    scanf("%ld", &parkplace->number);
}


int main() {
    int sizePark = 0;
    printf("Enter parking size: ");
    scanf("%d", &sizePark);
    struct vehicle *parking = (struct vehicle*) malloc(sizePark * sizeof(struct vehicle));
    char freeVar;
    struct vehicle *fillPtr = parking;
    for (int i = 0; i < sizePark; i++, printf("PASS\n"))
    {
        printf("\n\n\n\n\n");
        printf("PASS\n");
        printf("Car space %d\n\n", i+1);
        printf("Is the space taken?\n1. Yes\n0. No\n");
        fflush(stdin);
        scanf("%d", &freeVar);
        while (freeVar != 0 && freeVar != 1)
        {
            printf("Invalid choice.\n");
            printf("Is the space taken?\n1. Yes\n0. No\n");
            scanf("%d", &freeVar);
        }
        if (freeVar == 1)
        {
            fillPtr->id = i+1;
            registerParkingSpot(fillPtr);
        }
        else if (freeVar == 0) {
            fillPtr->status = 0;
            fillPtr->id = i+1;
            strcpy(fillPtr->model, "-");
            strcpy(fillPtr->registration, "-");
            strcpy(fillPtr->firstNameOwner, "-");
            strcpy(fillPtr->lastNameOwner, "-");
            fillPtr->nextCar = (fillPtr + sizeof(struct vehicle));
            fillPtr->number = 0;
        }
    }
    
    struct vehicle *ptr;
    while (ptr != NULL) {
        if (ptr->status == 1)
        {
            printf("Parkplace %02d\n", ptr->id);
            printf("Current renter: %s %s\n", ptr->firstNameOwner, ptr->lastNameOwner);
            printf("Car: %s - %s\n", ptr->model, ptr->registration);
            printf("Contact: %010d\n", ptr->number);
        }
        ptr = ptr->nextCar;
    }
    
    free(parking);
    return 0;
}